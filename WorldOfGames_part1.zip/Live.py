def welcome(name: str):
    print("Hello " + name + " and welcome to the World of Games (WoG)."'\n'"Here you can find many cool games to play.")


def load_game():
    game_number = input("Please choose a game to play: \n"
                        "1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it\n"
                        "2. Guess Game - guess a number and see if you chose like the computer\n"
                        "3. Currency Roulette - try and guess the value of a random amount of USD in ILS\n")
    while game_number not in ['1', '2', '3']:
        game_number = input("Invalid input! Please enter 1, 2 or 3: \n")

    game_difficulty = input("Please choose game difficulty from 1 to 5: "'\n')
    while game_difficulty not in ['1', '2', '3', '4', '5']:
        game_difficulty = input("Invalid input. Please choose game difficulty from 1 to 5: "'\n')

