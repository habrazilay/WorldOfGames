from Live import load_game, welcome

print(welcome("Daniel"))
load_game()