def check_victory(flag):
    if flag:
        print("Congratulations, you win!")
    else:
        print("Not this time you lose, try again!")
