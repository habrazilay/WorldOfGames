from currency_converter import CurrencyConverter
import random
c = CurrencyConverter()


def get_money_interval(v: float, d: int, t: int):
    us_to_ils_value = c.convert(v, 'USD', 'ILS')
    a = t - (5 - d)
    b = t + (5 - d)
    if a <= us_to_ils_value <= b:
        return True
    else:
        return False


def get_guess_from_user(d: int):
    random_value = random.randrange(1, 100)
    guess_from_user = input("What is the value of US$ " + str(random_value) + " in ILS currency?\n")
    while not guess_from_user.isnumeric():
        guess_from_user = input("Invalid Input. Guess a NUMBER please\n")
    return get_money_interval(int(random_value), d, int(guess_from_user))


def play(difficulty: int):
    return get_guess_from_user(difficulty)
