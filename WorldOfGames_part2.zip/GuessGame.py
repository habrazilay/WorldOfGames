import random


def generate_number(difficulty: int):
    secret_number = random.randrange(1, difficulty)
    return int(secret_number)


def get_guess_from_user(difficulty: int):
    user_number = input("Guess a number between 1 and " + str(difficulty) + '\n')
    while not user_number.isnumeric():
        user_number = input("Invalid Input. Guess a NUMBER between 1 and " + str(difficulty) + '\n')
    return int(user_number)


def compare_results(a: int, b: int):
    if a == b:
        return True
    else:
        return False


def play(difficulty: int):
    return compare_results(generate_number(difficulty), get_guess_from_user(difficulty)
)
