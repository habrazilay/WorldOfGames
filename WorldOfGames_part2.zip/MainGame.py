from Live import load_game, welcome
from CheckStatus import check_victory


print(welcome("Daniel"))
check_victory(load_game())
