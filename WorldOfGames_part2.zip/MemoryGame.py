import random


def generate_sequence(difficulty: int):
    num_list = []
    for num in range(difficulty):
        num_list.append(str(random.randrange(1, 101)))
    print(num_list)
    return num_list


def get_list_from_user(difficulty: int):
    user_number_list = []
    for i in range(difficulty):
        user_number = input("Guess the number " + str(i + 1) + " of the previews list\n")
        while not user_number.isnumeric():
            user_number = input("Invalid Input. Guess a NUMBER between 1 and 101\n")
        user_number_list.append(user_number)
    return user_number_list


def is_list_equal(list_a, list_b):
    list_a.sort()
    list_b.sort()
    if list_a == list_b:
        return True
    else:
        return False


def play(difficulty: int):
    return is_list_equal(generate_sequence(difficulty), get_list_from_user(difficulty))
